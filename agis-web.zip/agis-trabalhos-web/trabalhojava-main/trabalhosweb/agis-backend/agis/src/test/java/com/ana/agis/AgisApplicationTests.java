package com.ana.agis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgisApplicationTests {

	@Test
	void contextLoads() {
	}

}
